/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ip1;

/**
 *
 * @author Andrew
 */
public class Admin {
    
    public String CustomerStatus;
    public String TutorStatus;
    static Boolean newContact = false;
    static String search = "";
    static String bool = "";
    static int num;
    static String name[] = new String[3];
    static String surname[] = new String[3];
    static String email[] = new String[3];
    static String password[] = new String[3];
    
    public static void main(String[] args){
        
        
    }
    
}
