/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ip1;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author 30276399
 */


public class customerDB {
    
    
    public Customer GetCustomer(String Email){
     Database_Utilities.isDatabaseDriversExist();
        try {
            Connection con=Database_Utilities.getConnection();
            Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery ("SELECT * FROM Customer");
              rs.next();
              Customer customer = new Customer();
              customer.setCustomerID(rs.getInt("CustomerID"));
              customer.setEmail(rs.getString("Email"));
              customer.setPassword(rs.getString("Password"));
              customer.setFirstName(rs.getString("FirstName"));
              customer.setLastName(rs.getString("LastName"));
              return customer;
        } catch (SQLException ex){
            Logger.getLogger(customerDB.class.getName()).log(Level.SEVERE, null, ex);
        }
     
        return null;
     } 
     
    
    public Customer getValidCustomer(Customer pCustomer){
        //  boolean userExistsInDatabase = false;
        
        Database_Utilities.isDatabaseDriversExist(); // check that ucanaccess drivers exist
    
         try 
            {
                Connection con=Database_Utilities.getConnection();
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery ("SELECT CustomerId, FirstName, LastName, Email, Password  FROM customer WHERE Email='" + pCustomer.getEmail()+ "' AND " + " password=" + pCustomer.getPassword() );
               
                rs.next();//move to first record
                

              pCustomer.setCustomerID(rs.getInt("CustomerId"));
              pCustomer.setFirstName(rs.getString("FirstName"));
              pCustomer.setLastName(rs.getString("LastName"));
              pCustomer.setEmail(rs.getString("Email"));
              pCustomer.setPassword(rs.getString("Password"));
            }
         catch(SQLException e)
            {
                System.out.println("getValidUser : Error");
                System.out.println("SQL exception occured" + e);
            }
     
    //==========================================================='  
        return pCustomer;
    }
    
    public boolean checkUserIsValid(Customer pCustomer){
        boolean userExistsInDatabase = false;
      
         try 
            {
                Connection con=Database_Utilities.getConnection();
                Statement stmt = con.createStatement();
                ResultSet rs = stmt.executeQuery ("SELECT * FROM customer WHERE Email='" + pCustomer.getEmail()+ "' AND " + " password=" + pCustomer.getPassword() );
                while (rs.next()) 
                {        
                  userExistsInDatabase=true; // set if at least one record is found
                }
                
            }
         catch(SQLException ex)
            {
                System.out.println("checkUserIsValid : Error");
                System.out.println("SQL exception occured\n" + ex);
            }

    //==========================================================='  
    return (userExistsInDatabase);
    }
    
    public void insertCustomer(Customer pCustomer)
    {

         try 
            {
                Connection con=Database_Utilities.getConnection();
                Statement stmt = con.createStatement();
              //  pUser.getUserName();
               
                String mySql = "INSERT INTO Customer";
                mySql = mySql +  ("(FirstName, LastName, Email, Password)");
                mySql = mySql +  ("VALUES (") ;
                mySql = mySql +  ("'" +    pCustomer.getFirstName()    + "',") ;
                mySql = mySql +  ("'" +    pCustomer.getLastName()   + "',") ;
                mySql = mySql +  ("'"  +   pCustomer.getEmail() + "'," );
                mySql = mySql +  ("'" +    pCustomer.getPassword()   + "'");
                mySql = mySql +  (")") ;     
                System.out.println("the sql  - " + mySql);
                stmt.executeUpdate(mySql);
              

            }
         catch(SQLException ex)
            {
                System.out.println("checkUserIsValid : Error");
                System.out.println("SQL exception occured\n" + ex);
            }

    //==========================================================='  
   
    } 
   
    
    public Customer Login(String Email, String Password){
         Customer customerDB = GetCustomer(Email);
         if (customerDB!=null) {
             if (customerDB.getPassword().equals(Password)) {
                 return customerDB;
                 
             }
         }
         return null;
         
         
}
    
    
       
        
    

}
