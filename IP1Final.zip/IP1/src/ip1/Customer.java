/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ip1;

/**
 *
 * @author Andrew
 */

public class Customer {
    
    //attributes====================
    String firstName;
    String lastName;
    String email;
    String password;
    int customerID;
    int lessonID;
    String selectedLesson;
    boolean registered;
    String role;
    //======constructor===============
    
    public Customer(){
    //default constructor   
    }
    
    public Customer (String pfirstName, String plastName, String pemail , String ppassword, int pcustomerID, int plessonID, String pselectedLesson, boolean pregistered, String prole) 
    {
    //overloaded constructor    
    // these need guards !! - I have not added these but you should be adding these if you intend 
    // to use this overloaded constructor
    this.firstName=pfirstName; 
    this.lastName=plastName;
    this.email=pemail;
    this.password=ppassword;
    this.customerID=pcustomerID;
    this.lessonID=plessonID;
    this.selectedLesson=pselectedLesson;
    this.registered=pregistered;

    }
    
    //setters========================
    //p is telling me that this is a parameter variable   
    public void setFirstName(String pfirstName){
        // Accessor method- these guard aginst false data being use for state.
        if (!pfirstName.equals("")){
            this.firstName=pfirstName;
        }
        
    }
    public void setLastName(String plastName){
         // Accessor method- these guard aginst false data being use for state.
      // boolean flag=false;
         if (!plastName.equals("")){
            this.lastName=plastName;
        //    flag=true;
        }
      //  return flag;
    }
    public void setEmail(String pemail){
         // Accessor method- these guard against false data being use for state.
        if (!pemail.equals("")){
            this.email=pemail;
        }
    }
    public void setPassword(String ppassword){
        // Accessor method- these guard aginst false data being use for state.
        if (!ppassword.equals("")){
            this.password=ppassword;
        }
        
    }
    public void setCustomerID(int pcustomerID){
        // Accessor method- these guard aginst false data being use for state.
        if (pcustomerID > 0){
            this.customerID= pcustomerID;
        }
        
    }
  
      //===========getters========================
    
            public String getFirstName(){
        // Accessor method- these guard aginst false being use for state.
            return this.firstName;
    }
              public String getLastName(){
        // Accessor method- these guard aginst false being use for state.
            return this.lastName;
    }
         public String getEmail(){
        // Accessor method- these guard aginst false being use for state.
            return this.email;
    }
              public String getPassword(){
        // Accessor method- these guard aginst false being used for state.
            return this.password;
    }             
       public int getCustomerID(){
        // Accessor method- these guard aginst false being used for state.
            return this.customerID;
    }

    @Override
       public String toString(){

           StringBuilder theStringVersionOfTheUser= new StringBuilder();
           
           theStringVersionOfTheUser.append(this.firstName ).append(" , ");
           theStringVersionOfTheUser.append(this.lastName ).append(" , ");
           theStringVersionOfTheUser.append(this.email ).append(" , ");
           theStringVersionOfTheUser.append(this.password ).append(" , ");
           theStringVersionOfTheUser.append(this.customerID);
  
           
           
           return theStringVersionOfTheUser.toString();
       }
           
   
}
   

	
	
            

